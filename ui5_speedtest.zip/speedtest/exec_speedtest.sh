#!/bin/bash

php -f exec_speedtest.php
